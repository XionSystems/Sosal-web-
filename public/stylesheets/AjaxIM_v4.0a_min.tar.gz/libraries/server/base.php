<?php
class IM {
    function __construct() {
    }
    
    public function login($username, $password) {
        return array('e'=>'not implemented');
    }
    
    public function logout() {
        return array('e'=>'not implemented');
    }
    
    public function send($to, $message) {
        return array('e'=>'not implemented');
    }
    
    public function status($status, $message) {
        return array('e'=>'not implemented');
    }
    
    public function poll($method) {
    }
}

/* End of libraries/server/base.php */